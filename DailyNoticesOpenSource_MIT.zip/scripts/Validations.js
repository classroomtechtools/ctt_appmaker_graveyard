function isNew(itemDate) {
  return moment(app.datasources.TheseNotices.properties.SelectedDate).diff(moment(itemDate), 'days') === 0;
}

function validateStartsOn(widget, newValue) {

  if (!newValue) return "Required.";
  if (widget.datasource.item.StartsOn === null) return;
  if (widget.datasource.item.EndsOn === null) return;
  
  var today, currentStartsOn, currentEndsOn, value;
  today = new Date().getTime();
  currentStartsOn = widget.datasource.item.StartsOn.getTime();
  currentEndsOn = widget.datasource.item.EndsOn.getTime();
  value = newValue.getTime();
  
  if (widget.root.properties.Creating) {  // not null and not false
    // Make sure user does not attempt to add a notice for the past
    // Make sure end date occurs after start date
    if (newValue == today) return "Cannot make a notice for today. Did you mean to put in tomorrow?";
    if (newValue < today) return "Cannot make a notice for the past.";
  } else {
    // If it's a "live" notice, suggest to cancel instead
    if (currentStartsOn >= today && today <= currentEndsOn && value != currentStartsOn) {
     return "Once notices have started publication, the start date cannot be changed.";
    } 
  }
}

function validateEndsOn(widget, newValue) {
  if (widget.datasource.item.StartsOn === null) return;
  if (widget.datasource.item.EndsOn === null) return;

  if (!newValue) return "Required.";

  var today, currentStartsOn, currentEndsOn, value;
  today = new Date().getTime();
  currentStartsOn = widget.datasource.item.StartsOn.getTime();
  currentEndsOn = widget.datasource.item.EndsOn.getTime();
  value = newValue.getTime();
  
  if (currentEndsOn < currentStartsOn) return "The end date must be after the start date.";

  if (widget.root.properties.Creating) {
    // Make sure user does not attempt to add a notice for the past
    // Make sure end date occurs after start date

  } else {
    // If it's a "live" notice, suggest to cancel instead
    if (currentStartsOn >= today && today <= currentEndsOn && value != currentEndsOn) {
     if (value <= today) return "This is 'live' notice and so end date must be after today.";     
    } 
  }
}