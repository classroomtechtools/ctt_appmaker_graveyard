function SetUpSettings() {
  try {
    var settingsKey = app.datasources.Settings.item._key;
    Object.keys(app.datasources).filter(function (key) {
      return key.indexOf('_') !== 0;  // weed out internal properties
    }).forEach(function (name) {
      var ds;
      ds = app.datasources[name];
      if (ds.properties && ds.properties.hasOwnProperty('SettingsKey'))
        ds.properties.SettingsKey = settingsKey;
    });

  } catch(err) {

    console.log(err);
    
  } finally {
 
    //loader.resumeLoad();  

  }
     
}

function onAppLoad(loader) {
  //loader.suspendLoad();
  app.datasources.Settings.properties.UserEmail = app.user.email;
  app.datasources.MyNotices.properties.UserEmail = app.user.email;
  app.datasources.Settings.load(function () {
    // first time this user launched this app
    var create, draft;
    var response, record, ou;
    if (app.datasources.Settings.items.length === 0) {
      create = app.datasources.AllSettings.modes.create;
      draft = create.item;
      draft.UserEmail = app.user.email;
      draft.ProtectData = false;
      draft.SelectedDate = new Date();
      google.script.run
        .withSuccessHandler(function (ou) {
          if (!ou) {
            console.log("Did not get ou");
            app.datasources.TheseNotices.load(SetUpSettings);
            return;
          }
          app.datasources.TheseNotices.query.parameters.Audience = ou;
          draft.Ou = ou;
          create.createItem(function (record) {
            app.datasources.Settings.load(function () {
              // record created, now we're all good to continue
              app.datasources.TheseNotices.load(SetUpSettings);
            });
          });
        })
        .getOu(app.user.email);
    } else {
      // already set up, continue
      app.datasources.TheseNotices.query.parameters.Audience = app.datasources.Settings.item.Ou;  // FIXME: What if tied to
      app.datasources.TheseNotices.properties.SelectedDate = momentInKL().toDate();  //  new Date('2020/01/07');  // new Date();
      app.datasources.TheseNotices.load(SetUpSettings);
    }
  });
}