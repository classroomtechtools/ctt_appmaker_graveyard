function momentInKL(momentObj) {
  momentObj = momentObj || moment();
  return moment.tz(momentObj, "Asia/Kuala_Lumpur");
}
