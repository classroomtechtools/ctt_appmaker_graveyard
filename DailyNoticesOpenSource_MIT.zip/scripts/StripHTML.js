function getTextFromNode(x) {
 switch(x.toString()) {
  case 'XmlText': return x.toXmlString();
  case 'XmlElement': return x.getNodes().map(getTextFromNode).join(' ');
  default: return '';
 }
}

function getTextFromHtml(body) {
  return getTextFromNode(Xml.parse(body, true).getElement());
}

