function GetSettings(query) {
  console.log(query.parameters.SettingsKey);
  return app.models.Settings.getRecord(query.parameters.SettingsKey);
}

function getOu(email) {  
  var response;
  try {
    response = UrlFetchApp.fetch('https://script.google.com/a/igbis.edu.my/macros/s/AKfycbyWIJQEYPVJ2mn88EjvEkGKYjyF7L5-ESKz_er9k5gziChb0-w/exec?secret=phillies&user=' + email);
  } catch (e) {
    console.log(e.message);
    return null;
  }
  response = JSON.parse(response);
  return response.orgUnitPath.split('/')[1]; // TODO handle errors
}