var LOADER;
var COMPLETE_NUM = 0, MAX_STEPS = 3;
var FIRSTLOAD__steps = 0;
var FIRSTLOAD__max = 2;
function FirstLoad() {
  FIRSTLOAD__steps += 1;
  if (FIRSTLOAD__steps == FIRSTLOAD__max) {
      onFirstDatasourcesLoaded();
  }
}

function ThirdLoad() {
  LOADER.resumeLoad();
  COMPLETE_NUM += 1;
  if (COMPLETE_NUM === MAX_STEPS) { 
    app.popups.Snackbar.properties.informText = "Complete.";
    setTimeout(function () {
      app.popups.Snackbar.visible = false;
    }, 1000);
  }
}

function SecondLoad() {
  // called after settings is loaded
  
  app.datasources.ListButtons.query.parameters.SelectedAudience = [app.datasources.Settings.item.Ou];
  
  switchAudience_(app.datasources.Settings.item.Ou, true);

  //app.pages.Main.root.createChildren(); // now that we have the ou, start the loading process 
  switch ( app.pages.Main.properties.currentButtonArea ) {
    case "Buttons":
      app.datasources.Buttons.query.parameters.selectedCategoryKey = app.datasources.Settings.item.CategoryKey; // (app.datasources.Categories.item || {'_key': null})._key;
      app.datasources.Buttons.load(ThirdLoad);
      
      app.datasources.Categories.load(function () {
        app.datasources.Categories.selectKey(app.datasources.Buttons.query.parameters.selectedCategoryKey);
        ThirdLoad();
      });
      app.datasources.MyCategories.load(function () {
        app.datasources.MyButtons.query.parameters.selectedCategoryKey = (app.datasources.MyCategories.item || {'_key': null})._key;
        ThirdLoad();
      });
      break;
      
    case "MyButtons": 
      app.datasources.Categories.load(function () {
        app.datasources.Buttons.query.parameters.selectedCategoryKey = (app.datasources.Categories.item || {'_key': null})._key;
        ThirdLoad();
      });
      
      app.datasources.MyButtons.query.parameters.selectedCategoryKey = app.datasources.Settings.item.CategoryKey; // (app.datasources.MyCategories.item || {'_key': null})._key;
      app.datasources.MyButtons.load(ThirdLoad);

      app.datasources.MyCategories.load(function () {
        app.datasources.MyCategories.selectKey(app.datasources.MyButtons.query.parameters.selectedCategoryKey);
        ThirdLoad();
      });

      break;
  }
}

function onFirstDatasourcesLoaded() {
  // called after settings is loaded
  
  var SETUP_MAX = 1;
  var SETUP_COUNT = 0;
  
  function DefaultSetup() {
    // called after determined if we needed to create a new setting
    SETUP_COUNT += 1;
    if (SETUP_COUNT >= SETUP_MAX) {
      
      var settingsKey = app.datasources.Settings.item._key;
      ['Buttons', 'MyButtons'].forEach(function (name) {
        app.datasources[name].properties.SettingsKey = settingsKey;
      });
      app.pages.Main.properties.currentButtonArea = app.datasources.Settings.item.WhichButtonArea;
      switch (app.datasources.Settings.item.WhichButtonArea) {
        case 'Buttons':
          app.datasources.Buttons.query.parameters.selectedCategoryKey = app.datasources.Settings.item.CategoryKey;
          break;
        case 'MyButtons':
          app.datasources.MyButtons.query.parameters.selectedCategoryKey = app.datasources.Settings.item.CategoryKey;
          break;
        default:
          throw Error("Returned illegal value while onDefaultButtonsLoaded");
      }
      SecondLoad();  
    }
  }

  var create, draft;
  var response, record, ou;

  if (app.datasources.Settings.items.length === 0) {
    app.popups.Snackbar.properties.informText = 'New user…';
    create = app.datasources.AllSettings.modes.create;
    draft = create.item;
    draft.UserEmail = app.user.email;
    google.script.run
      .withSuccessHandler(function (ou) {
        draft.Ou = ou;
        draft.WhichButtonArea = 'Buttons';
        app.datasources.DefaultCategory.load(function () {
          draft.CategoryKey = (app.datasources.DefaultCategory.item || {_key: '1'})._key; 
          create.createItem(function (record) {
            app.datasources.Settings.load(function () {
              DefaultSetup();
            });
          });
        });
      })
      .getOu(app.user.email);
  } else {
    DefaultSetup();
  }
  
}

function getOuIcon_(id) {
  return {
    'students': 'face',
    'parents': 'supervised_user_circle',
    'staff': 'account_circle',
    'teachers': 'account_circle',
    'admin support': 'account_box',
  }[id.toLowerCase()] || 'check_circle';
}

/**
 * Do cursory checks for app readiness:
 * Must have organizational units updated
 * Must have Audience records created
 */
function checkInitiation_() {
  // if not an admin, ensure we have audience already created
  if (!app.user.role.Admins) return app.datasources.AudienceAll.items.length > 0;
  
  // we are an admin and we need to conduct test
  app.popups.Snackbar.properties.informText = 'Checking OUs…';
  FIRSTLOAD__max += 1;
  app.datasources.OUs.load(function () {
    var create, ids;
    if (app.datasources.OUs.items.length !== 0 && app.datasources.OUs.items.length > (app.datasources.AudienceAll.items.length-1)) {
      if (app.datasources.AudienceAll.items.length === 0) {
        create = app.datasources.AudienceAll.modes.create;
        FIRSTLOAD__max += 1;
        create.item.Name = 'Super Admin';
        create.item.MaterialIcon = 'build';
        create.item.Active = true;
        create.createItem(FirstLoad);
      }
      ids = app.datasources.AudienceAll.items.map(function (item) {
        return item.orgUnitId;
      });
      app.datasources.OUs.items.forEach(function (ouRecord) {
        if (ids.indexOf(ouRecord.orgUnitId) === -1) {
          FIRSTLOAD__max += 1;
          console.log("Creating " + ouRecord.name);
          create = app.datasources.AudienceAll.modes.create;
          create.item.Name = ouRecord.name;
          create.item.orgUnitId = ouRecord.orgUnitId;
          create.item.MaterialIcon = 'radio_button_unchecked';  // plain, boring circle
          create.item.Active = false;
          create.createItem(FirstLoad);
        }
      });
    }
    FirstLoad(); 
  });
  return true;
}

function FailOnLoad(firstMessage) {
  function actOnFailure(err) {
    var message;
    switch (true) {
      case /^Timeout with OU Service/.test(err.message):
        message = 'We recently have been seeing some timeouts with some backend services we use to complete the login. We are working on it.\n\nYou can try again later or refresh now.';
        break;
        
      case /^Unknown OU/.test(err.message):
        message = 'It appears that we have placed you into an uknown Organizational Unit (OU). Please contact us with a screenshot of this and we will be able to fix this for you.';
        break;
        
      default:
        message = "Unknown error. Please contact the IT HelpDesk.\n";
        break;
    }
    app.popups.ErrorDialog.descendants.description.text = firstMessage + message;
    app.popups.ErrorDialog.descendants.title.text = err.toString();
    app.popups.ErrorDialog.visible = true;
  }
  return actOnFailure;
}

function onAppLoad(loader) {
  LOADER = loader;
  //LOADER.suspendLoad();

  app.pages.Main.properties.standardRole = true;
  app.popups.Snackbar.properties.informText = 'Loading App…';
  app.popups.Snackbar.visible = true;
  
  app.pages.Main.properties.InEditMode = false;  // this should probably go in onAttach?

  app.datasources.MyCategories.query.parameters.currentUser = app.user.email;
  //app.datasources.DefaultButtons.query.parameters.currentUserEmail = app.user.email;
  //app.datasources.ListButtons.query.parameters.UserEmail = app.user.email;
  
  app.datasources.Settings.properties.currentUserEmail = app.user.email;
  app.datasources.Settings.load({
    success: FirstLoad,
    failure: FailOnLoad("This error occurred during Settings load")
  });
  
  app.datasources.AudienceAll.load(function () {
    if (checkInitiation_()) { // also calls FirstLoad inside
      FirstLoad();
    } else {
      app.popups.Snackbar.properties.informText = 'Requires a super admin to use this app first.';
      app.popups.Snackbar.visible = true;
    }
  });

}
