function unstar(id) {
  var response;
  
  try {
    response = Drive.Files.update({
      labels: {
        "starred": false
      }
    }, id);
    
    makeUserButtonsDirty();
  } catch (e) {
    if (e.message.indexOf("API call to drive.files.update failed with error: File not found") === 0) 
      throw Error("Teamdrive files not supported");
    throw e;
  }
}