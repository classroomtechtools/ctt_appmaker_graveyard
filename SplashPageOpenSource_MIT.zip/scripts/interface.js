
function userClickedDownward(widget, event, buttonArea) {
  var datasource, pos, saved2;
  app.popups.Snackbar.properties.informText = 'Updating…';
  app.popups.Snackbar.visible = true;
  datasource = app.datasources[buttonArea];
  pos = datasource.items[datasource.itemIndex].Position;
  datasource.items[datasource.itemIndex].Position = datasource.items[datasource.itemIndex+1].Position;
  datasource.items[datasource.itemIndex+1].Position = pos;

  datasource.saveChanges(function () {
    datasource.load(function () {
      app.popups.Snackbar.properties.informText = 'Complete';
      setTimeout(function () {
        app.popups.Snackbar.visible = false;
      }, 1000);
    });
  });  
}

function userClickedUpward(widget, event, buttonArea) {
  var datasource, pos, saved2;
  app.popups.Snackbar.properties.informText = 'Updating…';
  app.popups.Snackbar.visible = true;
  datasource = app.datasources[buttonArea];
  pos = datasource.items[datasource.itemIndex].Position;
  datasource.items[datasource.itemIndex].Position = datasource.items[datasource.itemIndex-1].Position;
  datasource.items[datasource.itemIndex-1].Position = pos;

  datasource.saveChanges(function () {
    datasource.load(function () {
      app.popups.Snackbar.properties.informText = 'Complete';
      setTimeout(function () {
        app.popups.Snackbar.visible = false;
      }, 1000);
    });
  });  
}

function saveForNextAppLoad(buttonArea, catKey) {
  // Update the Default Buttons to save it for retrieval on app start
  app.datasources.Settings.item.WhichButtonArea = buttonArea;
  app.datasources.Settings.item.CategoryKey = catKey;  
}

function userClickedTab(widget) {
  var save, bds;
  bds = widget.root.properties.ButtonDataSource;
  save = app.pages.Main.properties.InEditMode;
  
  var buttonDatasource = app.datasources[bds];

  buttonDatasource.properties.selectedCategoryKey = widget.root.properties.Key;
  saveForNextAppLoad(bds, widget.root.properties.Key);

  // Tell the display controller to update the user interface, and start the reload process
  buttonDatasource.load(function () {
    app.pages.Main.properties.currentButtonArea = bds;  // here avoids flicker
    app.pages.Main.properties.InEditMode = save;
  }); 
}

function userClickedDropdown(widget, newValue) {
  var buttonDatasource = app.datasources[widget.root.properties.ButtonDataSource];
  app.pages.Main.descendants.MyCategoriesGrid.visible = true;
  saveForNextAppLoad(widget.root.properties.ButtonDataSource, newValue.valueOf());
  
  buttonDatasource.properties.selectedCategoryKey = newValue.valueOf();
  if (widget.root.properties.ButtonDataSource == 'Buttons') 
    app.datasources.Categories.selectKey(newValue.valueOf());
  if (widget.root.properties.ButtonDataSource == 'MyButtons') 
    app.datasources.MyCategories.selectKey(newValue.valueOf());
  buttonDatasource.load();
}