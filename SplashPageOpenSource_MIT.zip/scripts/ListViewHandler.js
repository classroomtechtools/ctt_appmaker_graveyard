
function TrackCounts(number, callback) {
  var count = 0;
  var store = {};
  return function (which, storedVersion) {
    var localVersion;

    count += 1;

    // pin local version to variable
    localVersion = window.localStorage.getItem(which + 'Version') || '0';
    if (isNaN(localVersion)) localVersion = '0';
    if (isNaN(storedVersion)) storedVersion = MAX_VALUE.toString();

    // determine if "dirty"
    store[which] = parseInt(storedVersion) > parseInt(localVersion);

    // update
    window.localStorage.setItem(which + 'Version', storedVersion);
    
    if (count == number) {
      if (Object.keys(store).some(function (key) {
        return store[key];
      })) {
        // TODO: Do we just want logic to load one and not the other?        
        app.datasources.ListButtons.load(stepOriginal);
        app.datasources.StarredList.load(stepOriginal);
      } else {
        if (!window.localStorage || !window.localStorage.splash_listbuttons) {
          app.datasources.ListButtons.load(stepOriginal);
          app.datasources.StarredList.load(stepOriginal);
        } else {
          callback.success(fromStore());
        }
      }      
    }
  };
}


function handleListView(query, factory, callback) {
  
  var STEP = 0;
  var STORE = {};
  function determineCallback(which, storedVersion) {
    // determine which callback to set to
    var localVersion;
  
    // pin local version to variable
    localVersion = window.localStorage.getItem(which + 'Version') || '0';
    if (isNaN(localVersion)) localVersion = '0';
    if (isNaN(storedVersion)) storedVersion = MAX_VALUE.toString();
    
    // determine if "dirty"
    STORE[which] = parseInt(storedVersion) > parseInt(localVersion);
    
    // update
    window.localStorage.setItem(which + 'Version', storedVersion);
    
    STEP+=1;
    if (STEP === 2) {
      STEP = 0;
      if (Object.keys(STORE).some(function (key) {
        return STORE[key];
      })) {
        // TODO: Do we just want logic to load one and not the other?        
        app.datasources.ListButtons.load(stepOriginal);
        app.datasources.StarredList.load(stepOriginal);
      } else {
        if (!window.localStorage || !window.localStorage.splash_listbuttons) {
          app.datasources.ListButtons.load(stepOriginal);
          app.datasources.StarredList.load(stepOriginal);
        } else {
          callback.success(fromStore());
        }
      }
    }
  }  
  
  function filterPass(records) {
    if (!query.parameters.StringFilter) return records;
    return records.filter(function (record) {
      return record.Display.toLowerCase().indexOf(query.parameters.StringFilter.toLowerCase()) !== -1;
    });
  }
  
  function handleVersions(which, key) {
    google.script.run.withSuccessHandler(function (result) {
      determineCallback(which, result || true);
      TrackCounts(2, function () {
        
      });
    })
    .getVersion(which, key);
  }

  function handleGlobalButtons() {
    google.script.run.withSuccessHandler(function (result) {
      determineCallback('script', result || false);
    })
    .getVersion('Script', 'buttons');
  }

  function fromOriginal() {
    var store, values = [];
    store = app.datasources.ListButtons.items.map(function (item) {
      var record, value = {};
      record = factory.create();
      record.Display = value.Display = item.DisplayName;
      record.Location = value.Location = item.Categories.Name;
      record.Link = value.Link = item.Link;
      values.push(value);
      return record;
    }).concat(app.datasources.StarredList.items.map(function (item) {
      var record, value = {};
      record = factory.create();
      record.Display = value.Display = item.DisplayName;
      record.Location = value.Location = 'Starred';
      record.Link = value.Link = item.Link;
      values.push(value);
      return record;
    })).sort(function (a, b) {
      return a.Display.localeCompare(b.Display);      
    });
    values = values.sort(function (a, b) {
      return a.Display.localeCompare(b.Display);
    });
    if (window.localStorage) window.localStorage.setItem('splash_listbuttons', JSON.stringify(values));
    return filterPass(store);
  }

  function fromStore () {
    // see if anything available in store, if not, fallback to fromOriginal
    var ret, values;
    
    if (!window.localStorage) throw Error("Local Storage unavailable");
    if (!window.localStorage.splash_listbuttons) throw Error("Nothing in local storage");
    
    try {
      values = JSON.parse(window.localStorage.getItem('splash_listbuttons'));
    } catch (e) {
      window.localStorage.removeItem('splash_listbuttons');
      console.log('oops: ' + window.localStorage.getItem('splash_listbuttons'));
      return fromOriginal();
    }
    ret = values.map(function (value) {
      var record;
      record = factory.create();
      Object.keys(value).forEach(function (field) {
        record[field] = value[field];
      });
      return record;
    });
    
    return filterPass(ret);
  }
  
  var STEPORIG = 0;
  function stepOriginal () {
    var store;
    STEPORIG += 1;
    if (STEPORIG == 2) {
      callback.success(fromOriginal());
    }
  }

  //var STEP = 0;
  //var STORE = {};
  function determineCallback(which, storedVersion) {
    // determine which callback to set to
    var localVersion;
  
    // pin local version to variable
    localVersion = window.localStorage.getItem(which + 'Version') || '0';
    if (isNaN(localVersion)) localVersion = '0';
    if (isNaN(storedVersion)) storedVersion = MAX_VALUE.toString();
    
    // determine if "dirty"
    STORE[which] = parseInt(storedVersion) > parseInt(localVersion);
    
    // update
    window.localStorage.setItem(which + 'Version', storedVersion);
    
    STEP+=1;
    if (STEP === 2) {
      STEP = 0;
      if (Object.keys(STORE).some(function (key) {
        return STORE[key];
      })) {
        // TODO: Do we just want logic to load one and not the other?        
        app.datasources.ListButtons.load(stepOriginal);
        app.datasources.StarredList.load(stepOriginal);
      } else {
        if (!window.localStorage || !window.localStorage.splash_listbuttons) {
          app.datasources.ListButtons.load(stepOriginal);
          app.datasources.StarredList.load(stepOriginal);
        } else {
          callback.success(fromStore());
        }
      }
    }
  }
  
  handleVersions('User', 'buttons');
  handleVersions('Script', 'buttons');

}