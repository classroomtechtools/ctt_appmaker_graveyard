function deleteAllSettings() {
  var allRecords = app.models.Settings.newQuery().run();
  app.deleteRecords(allRecords);
}


function incrementVersion(which, key) {
  var prop, value;
  if (['User', 'Script'].indexOf(which) === -1) throw Error("Expecting 'User' or 'Script'");

  prop = PropertiesService[ 'get' + which + 'Properties' ].call(PropertiesService);
  value = prop.getProperty(key + 'Version');
  if (!value || isNaN(value)) {
    value = '0';
  }
  value = (parseInt(value) + 1).toString();
  //if (CONSOLE) console.log(which + ' incremented to ' + value);
  prop.setProperty(key + 'Version', value);
  return value;
}

function getVersion(which, key) {
  var prop, value;  
  if (['User', 'Script'].indexOf(which) === -1) throw Error("Expecting 'User' or 'Script'");

  prop = PropertiesService[ 'get' + which + 'Properties' ].call(PropertiesService);
  //if (CONSOLE) console.log('key: ' + key);
  value = prop.getProperty(key + 'Version');
  if (!value || isNaN(value)) {
    value = incrementVersion(which, key);
  }
  //if (CONSOLE) console.log('value: ' + value);
  return value;
}

function makeUserButtonsDirty() {
  incrementVersion('User', 'buttons');
}

function makeGlobalButtonsDirty() {
  incrementVersion('Script', 'buttons');
}


