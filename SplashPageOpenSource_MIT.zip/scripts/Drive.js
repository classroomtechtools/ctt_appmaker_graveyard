function getIcon_(id) {
  switch (id) {
    case 'application/vnd.google-apps.document':
      return 'file-alt';
    case 'application/vnd.google-apps.drawing':
      return 'file-image';
    case 'application/vnd.google-apps.file':
    case 'application/vnd.google-apps.drive-sdk':
      return 'file';
    case 'application/vnd.google-apps.folder':
      return 'folder';
    case 'application/vnd.google-apps.form':
      return 'file-contract';
    case 'application/vnd.google-apps.spreadsheet':
      return 'file-medical-alt';
    case 'application/vnd.google-apps.audio':
      return 'headphones';
    case 'application/vnd.google-apps.fusiontable':
      return 'table';
    case 'application/vnd.google-apps.map':
      return 'map-marked-alt';
    case 'application/vnd.google-apps.presentation':
      return 'file-invoice';
    case 'application/vnd.google-apps.script':
      return 'file-code';
    case 'application/vnd.google-apps.site':
      return 'sitemap';
    case 'application/vnd.google-apps.video':
      return 'video';
    default:
      return 'question';
  }
}

function getColor_(id) {
  switch (id) {
    case 'application/vnd.google-apps.document':
    case'application/vnd.google-apps.script':   
      return '#0074D9';
    case 'application/vnd.google-apps.drawing':
    case 'application/vnd.google-apps.map':
    case 'application/vnd.google-apps.audio':
      return '#E4766C';
    case 'application/vnd.google-apps.drive-sdk':
    case 'application/pdf':
      return '#eeeeee';
    case 'application/vnd.google-apps.folder':
      return '#A6A6A6';
    case 'application/vnd.google-apps.form':
    case 'application/vnd.google-apps.site':
      return '#AD9BC8';
    case 'application/vnd.google-apps.spreadsheet':
      return '#479A5F';
    case 'application/vnd.google-apps.presentation':
      return '#CC9900';
    case 'on/vnd.google-apps.video':
      return '#c7cbbc';
    case 'application/vnd.google-apps.file':
      return '#C7EA46';
    default:
      return '#111';
  }
}

function SearchStarred_(query) {
  var files, file, record, ret = [], pos = 0, name, token, orderBy;
  orderBy = query.parameters.Query || 'lastViewedByMeDate desc';
  do {
    files = Drive.Files.list({
      q: 'starred = true',
      maxResults: 100,
      pageToken: token,
      orderBy: orderBy,
      supportsAllDrives: true,
      supportsTeamDrives: true,
      spaces: 'drive',
      includeItemsFromAllDrives: true
    });
    (files.items || []).forEach(function (file) {
      pos += 1;
      name = file.title;
      if (!query.parameters.StringFilter || (query.parameters.StringFilter && (name.toLowerCase().indexOf(query.parameters.StringFilter.toLowerCase()) !== -1))) {
        record = app.models.Drive.newRecord();
        record.DriveId = file.id;
        record.IsStarred = true;
        record.DisplayName = name;
        record.IconValue = getIcon_(file.mimeType);
        record.Link = file.alternateLink;  // file.getUrl();
        record.ColorValue = getColor_(file.mimeType);
        record.TitleValue = setItemTitleColor_(record);
        record.ViewedByMeTime = file.lastViewedByMeDate ? new Date(file.lastViewedByMeDate) : null;
        ret.push(record);
      }
    });
  } while (token);
  
  return ret;
}

