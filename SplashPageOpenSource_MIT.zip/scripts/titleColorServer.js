function setFaPrefix_(item) {
 switch (item.IconValue) {
   case 'google-drive':
     item.FaPrefix = 'fab';
     break;
   default:
     item.FaPrefix = 'fas';
 }
}

function setIconValue_(item) {
 switch (item.MimeTsype) {
   case 'application/vnd.google-apps.folder':
     item.IconValue = 'folder';
     break;
   default:
     item.IconValue = 'google-drive';
     break;
 }
}

function setColor_(item) {
  switch (item.MimeType) {
    case 'application/vnd.google-apps.document':
      item.ColorValue = '#4688F1';
      break;
    case 'application/vnd.google-apps.drawing':
      item.ColorValue = '#C94031';
      break;
    case 'application/vnd.google-apps.presentation':
      item.ColorValue = '#EBB53E';
      break;
    case 'application/vnd.google-apps.spreadsheet':
      item.ColorValue = '#479A5F';
      break;
    case 'application/vnd.google-apps.folder':
      item.ColorValue = '#EEEEEE';
      break;
    case 'application/vnd.google-apps.form':
      item.ColorValue = '#5A46AA';
      break;
    /* case 'application/vnd.google-apps.fusiontable':
      item.ColorValue = 'FTABLE';
      break; */
    case 'application/vnd.google-apps.photo':
    case 'application/vnd.google-apps.map':
      item.ColorValue = '#CB4F40';
      break;
    case 'application/vnd.google-apps.script':
      item.ColorValue = '#3275E0';
      break;
    case 'application/vnd.google-apps.site':
      item.ColorValue = '#4E5FB4';
      break;
    case 'application/vnd.google-apps.unknown':
      item.ColorValue = '#999';
      break;
    case 'application/vnd.google-apps.video':
      item.ColorValue = '#C94031';
      break;
    case 'application/vnd.google-apps.drive-sdk':
      item.ColorValue = '#999999';
      break;
    case 'application/pdf':
      item.ColorValue = '#C94031';
      break;
    default:
      item.ColorValue = '#AAAAAA';
      break;
  }
}

function setItemKind_(item) {
  switch (item.MimeType) {
    case 'application/vnd.google-apps.document':
      item.Kind = 'DOC';
      break;
    case 'application/vnd.google-apps.drawing':
      item.Kind = 'DRAW';
      break;
    case 'application/vnd.google-apps.spreadsheet':
      item.Kind = 'SHEET';
      break;
    case 'application/vnd.google-apps.presentation':
      item.Kind = 'SLIDE';
      break;
    case 'application/vnd.google-apps.file':
      item.Kind = 'FILE';
      break;
    case 'application/vnd.google-apps.folder':
      item.Kind = 'FOLDER';
      break;
    case 'application/vnd.google-apps.form':
      item.Kind = 'FORM';
      break;
    case 'application/vnd.google-apps.fusiontable':
      item.Kind = 'TABLE';
      break;
    case 'application/vnd.google-apps.map':
      item.Kind = 'MAP';
      break;
    case 'application/vnd.google-apps.photo':
      item.Kind = 'PHOTO';
      break;
    case 'application/vnd.google-apps.script':
      item.Kind = 'SCRIPT';
      break;
    case 'application/vnd.google-apps.site':
      item.Kind = 'SITE';
      break;
    case 'application/vnd.google-apps.unknown':
      item.Kind = '?';
      break;
    case 'application/vnd.google-apps.video':
      item.Kind = 'VIDEO';
      break;
    case 'application/vnd.google-apps.drive-sdk':
      item.Kind = 'OTHER';
      break;
    case 'application/vnd.google-apps.appmaker':
      item.Kind = 'APP';
      break;
    case 'application/pdf':
      item.Kind = 'PDF';
      break;
    default:
      item.Kind = '';
      break;
  }
}

function setItemTitleColor_(item) {
  switch (item.ColorValue.toUpperCase()) {
    case '#EEEEEE':
      item.TitleValue = '#111111';
      break;
    case '#C94031':
      item.TitleValue = '#f9ebea';
      break;
    case '#5A46AA':
      item.TitleValue = '#eeecf6';
      break;
    case '#8F8F8F':
      item.TitleValue = '#f3f3f3';
      break;
    case '#CB4F40':
      item.TitleValue = '#140706';
      break;
    case '#EBB53E':  // google slide
      item.TitleValue = '#171206';
      break;
    case '#4688F1':  // google doc
      item.TitleValue = '#ecf3fd';
      break;
    case '#3275E0':
      item.TitleValue = '#050b16';
      break;
    case '#479A5F':  // google sheet
      item.TitleValue = '#ecf4ef';
      break;
    case '#001F3F':  // navy blue
      item.TitleValue = '#e5e8eb';
      break;
    case '#0074D9':  // blue
      item.TitleValue = '#e5f1fb';
      break;
    case '#7FDBFF':  // aqua
      item.TitleValue = '#0c1519';
      break;
    case '#3D9970':  // olive
      item.TitleValue = '#122d21';
      break;
    case '#2ECC40':  // greem
      item.TitleValue = '#041406';
      break;
    case '#FFDC00':  // yellow
      item.TitleValue = '#191600';
      break;
    case '#FF851B':  // orange
      item.TitleValue = '#190d02';
      break;
    case '#FF4136':  // red
      item.TitleValue = '#190605';
      break;
    case '#85144B':  // maroon
      item.TitleValue = '#f2e7ed';
      break;
    case '#F012BE':  // fuchsia
      item.TitleValue = '#fde7f8';
      break;
    case '#B10DC9':  // purple
      item.TitleValue = '#f7e6f9';
      break;
    case '#111111':  // black
      item.TitleValue = '#e7e7e7';
      break;
    case '#B7B74C':
      item.TitleValue = '#121207';
      break;
    case '#39CCCC':  // teal
      item.TitleValue = '#051414';
      break;
    case '#DDDDDD':  // silver
      item.TitleValue = '#161616';
      break;
    case '#4E5FB4':
      item.TitleValue = '#edeff7';
      break;
    case '#999999':
      item.TitleValue = '#0f0f0f';
      break;
    case '#003F1F':
      item.TitleValue= '#DDE5E1';
      break;
    case '#AAA':
    case '#AAAAAA':  // gray
      item.TitleValue = '#efefef';
      break;
    case '#B10DC9':
      item.TitleValue = '#fde7f8';
      break;
    case '#EF12BD':
      item.TitleValue = 'white';
      break;
    case '#3F001F':
      item.TitleValue = '#D7CAD1';
      break;
    case '#00CC59':
      item.TitleValue = '#122d21';
      break;
    case '#7D9D8D':
      item.TitleValue = '#111613';
      break;
    case '#A08080':
      item.TitleValue = '#1E0E0E';
      break;
    default:
      item.TitleValue = '#111';
  }
}

function updateButtonRecord(record, fields) {
  fields = fields || 'MimeType,Kind,IconValue,FaPrefix,ColorValue,TitleValue';
  fields = fields.split(',').reduce(function (acc, field) {
    acc[field] = true;
    return acc;
  }, {});
  if (fields.MimeType) record.MimeType = record.MimeType  || 'application/splash.button_user_created';
  if (fields.Kind) setItemKind_(record); 
  if (fields.IconValue) setIconValue_(record);
  if (fields.FaPrefix) setFaPrefix_(record);
  if (fields.ColorValue) setColor_(record);
  if (fields.TitleValue) setItemTitleColor_(record);

  return record;
}