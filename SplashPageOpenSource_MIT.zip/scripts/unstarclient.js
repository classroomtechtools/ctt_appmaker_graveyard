function unstarThis(widget) {
  //widget.root.descendants.UnstarButton.visible = false;
  widget.root.descendants.Spinner1.visible = true;
  widget.enabled = false;
  google.script.run
    .withSuccessHandler(function  () {
      widget.root.descendants.Spinner1.visible = false;
      widget.text = 'Successfully unstarred';
      widget.styles = ['completed'];

    })
    .withFailureHandler(function (error) {
      widget.root.descendants.Spinner1.visible = false;
      widget.styles = ['incomplete'];
      widget.text = error.message;
    })
    .unstar(widget.root.properties.Id);
}