function checkDSDirty (info) {
  if (
    (info.useUserStore && PropertiesService.getUserProperties().getProperty(info.storeKey) === '1') ||
    (info.useGlobalStore && PropertiesService.getScriptProperties().getProperty(info.storeKey) === '1')
  ) {
     throw Error("Dirty");
  }
  // okay.
}

function makeDSDirty (key) {
  return PropertiesService.getUserProperties().getProperty(key) === '1';
}

function clearDSDirty (key) {
  
}