function getOu(email) {
  var response, record, ou, split;  
  try {
    response = UrlFetchApp.fetch('https://script.google.com/a/igbis.edu.my/macros/s/AKfycbyWIJQEYPVJ2mn88EjvEkGKYjyF7L5-ESKz_er9k5gziChb0-w/exec?secret=phillies&user=' + email);
  } catch (err) {
    throw Error("Timeout with OU Service");
  }
  try {
    response = JSON.parse(response);
  } catch (err) {

  }

  split = response.orgUnitPath.split('/'); // TODO handle errors
  ou = split[1];
  if (!ou && query.parameters.currentUserEmail.indexOf('.parents@') !== -1) {
    ou = 'Parents';   // parents is safe to do this way, but don't want to expose staff accidentally
  }
  if (!ou) throw Error("Unknown OU: " + ou);
  
  return ou; 
}