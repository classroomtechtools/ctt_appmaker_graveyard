function CC(ds, query, factory, callback, options) {
  var prop, local;
  
  options = options || {};
  options.storeKey = options.storeKey || ds.name;
  options.useUserStore = options.useUserStore === undefined ? true : options.useUserStore;
  options.useGlobalStore = options.useGlobalStore === undefined ? true : options.useGlobalStore;
  
  function manualLoad() {
    console.log("loading " + options.storeKey + " manually");
    ds.load(function () {
      var values = [];
      callback.success(ds.items.map(function (item) {
        var record, value = {};
        record = factory.create();
        Object.keys(ds.model.fields).forEach(function (field) {
          if (field[0] === '_') return;
          record[field] = value[field] = item[field];
        });
        values.push(value);
        return record;
      }));
      localStorage.setItem( options.storeKey, JSON.stringify(values) );
    });
  }

  if (options.off) {
    manualLoad();
  } else {

    google.script.run
      .withSuccessHandler(function (result) {
        // it's okay to try and use the cache
        local = localStorage.getItem(options.storeKey);
        if (local) {
          console.log(options.storeKey + " from cache");
          console.log(local);
          callback.success(
            JSON.parse(local).map(function (item) {
              var record;
              record = factory.create();
              for (var field in item) {
                record[field] = item[field];
              }
              return record;
            })
          );
        } else {
          manualLoad();
        }
      })
      .withFailureHandler(function (err) {
        // it's dirty ... or some other problem
        manualLoad();
      })
      .checkDSDirty(options);
    
  }
}

