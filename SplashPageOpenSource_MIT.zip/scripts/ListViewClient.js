function ListViewClient(query, recordFactory, callback) {

  var collect_STEP = 0, collect_MAX = 2, buttons, myButtons;
  
  buttons = app.datasources.Buttons.items.filter(function (item) {
    return !query.parameters.Search || item.toLowerCase().indexOf(item.DisplayName.toLowerCase());
  });
  
  myButtons = app.datasources.MyButtons.items.filter(function (item) {
    
  });
  
  function Collect() {
    collect_STEP += 1;    
    
    if (collect_STEP === collect_MAZ) {
      
    }
  }

  
}