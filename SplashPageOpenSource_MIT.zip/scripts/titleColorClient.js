function setItemTitleColor_(item) {
  switch (item.ColorValue.toUpperCase()) {
    case '#EBB53E':  // google slide
      item.TitleValue = '#FCF2DE';
      break;
    case '#4688F1':  // google doc
      item.TitleValue = '#F4F8FE';
      break;
    case '#479A5F':  // google sheet
      item.TitleValue = '#F8FCF9';
      break;
    case '#001F3F':  // navy blue
      item.TitleValue = '#F2E7FF';
      break;
    case '#0074D9':  // blue
      item.TitleValue = '#B3DBFF';
      break;
    case '#7FDBFF':  // aqua
      item.TitleValue = '#004966';
      break;
    case '#3D9970':  // olive
      item.TitleValue = '#163728';
      break;
    case '#2ECC40':  // greem
      item.TitleValue = '#0E3E14';
      break;
    case '#01FF70':  // lime
      item.TitleValue = '#00662C';
      break;
    case '#7D9D8D':
      item.TitleValue = '#111613';
      break;
    case '#FFDC00':  // yellow
      item.TitleValue = '#665800';
      break;
    case '#FF851B':  // orange
      item.TitleValue = '#663000';
      break;
    case '#FF4136':  // red
      item.TitleValue = '#FFD1CE';
      break;
    case '#85144B':  // maroon
      item.TitleValue = '#EB7AB1';
      break;
    case '#F012BE':  // fuchsia
      item.TitleValue = '#fde7f8';
      break;
    case '#B10DC9':  // purple
      item.TitleValue = '#EFA9F9';
      break;
    case '#111111':  // black
      item.TitleValue = '#ddd';
      break;
    case '#B7B74C':
      item.TitleValue = '#e9e9c9';
      break;
    case '#3F001F':
      item.TitleValue = '#D7CAD1';
      break;
    case '#A08080':
      item.TitleValue = '#1E0E0E';
      break;
    case '#003F1F':
      item.TitleValue= '#DDE5E1';
      break;
    case '#39CCCC':  // teal
    case '#AAAAAA':  // gray
    case '#DDDDDD':  // silver
      item.TitleValue = '#000000';
      break;
    default:
      item.TitleValue = '#111';
  }
}

function determineTitleColor_(datasource) {
  datasource.items.forEach(function (item) {
  	setItemTitleColor_(item);
  });
}