function onSelectGoogleFile(widget, result, options) {
  var doc, name, icon, color, kind;
  options = options || {};
  options.create = options.create || false;
  options.category = options.category || 'MyCategories';
  
  app.popups.Snackbar.properties.informText = options.create ? 'Creating Button…' : 'Generating Preview…';
  app.popups.Snackbar.visible = true;

  doc = result.docs[0];
  name = doc.name.replace(/\.[^/.]+$/, "");  // remove extention
  
  var draft, dsname;
  dsname = widget.name.split('_')[1];
  draft = widget.datasource.item; // grab the one we're working on in the front end
  draft.Categories = app.datasources[options.category].item;

  google.script.run
    .withSuccessHandler(function (result, item) {
      Object.keys(result).forEach(function (key) {
        item[key] = result[key];
      });

      function onComplete () {
        app.popups.Snackbar.properties.informText = 'Complete.';
        setTimeout(function () {
          app.popups.Snackbar.visible = false;    
        }, 1000);       
      }
    
      if (options.create) {
        item.Position = app.datasources[dsname].items.length + 1;
        widget.datasource.saveChanges(onComplete);
      } else {
        onComplete();
      }

    })
  
    .withFailureHandler(function (error) {
      console.log(error);
      app.popups.Snackbar.properties.informText = error.message;
    })
  
    .withUserObject(draft)
  
    .updateButtonRecord({
      DisplayName: name,
      Link: doc.mimeType === 'application/vnd.google-apps.form' ? doc.url.replace('/edit', '/viewform') : doc.url,
      MimeType: doc.mimeType
    }, 'Kind,IconValue,FaPrefix,ColorValue,TitleValue');

}