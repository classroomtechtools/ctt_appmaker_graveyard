var onComplete__steps = 0;
function onComplete() {
  onComplete__steps += 1;
  if (onComplete__steps == 1) {    
    app.popups.Snackbar.properties.informText = app.datasources.Audience.item.Name + ' role';
    setTimeout(function () {
      app.popups.Snackbar.visible = false;
      onComplete__steps = 0;
    }, 1000);
  }
}

function switchContext_(widget, event) {
  app.pages.Main.properties.InEditMode = false;
  switchAudience_(widget.text);
  app.popups.SwitchContext.visible = false; 
  app.popups.Snackbar.properties.informText = 'Changing to new role …';
  app.popups.Snackbar.visible = true;
  app.pages.Main.properties.currentButtonArea = 'Buttons';
  app.pages.Main.properties.standardRole = (app.datasources.Settings.item.Ou === app.datasources.Audience.item.Name);
  app.datasources.Buttons.load(function () {
    app.popups.Snackbar.properties.informText = app.datasources.Audience.item.Name + ' role';
    setTimeout(function () {
      app.popups.Snackbar.visible = false;
      onComplete__steps = 0;
    }, 1000); 
  });
  
}

function switchAudience_(ou) {
  var ds, go__max = 3, go__step = 0, save;
  ds = app.datasources.GetAudience;

  app.datasources.Buttons.query.parameters.currentUserOU = 
    app.datasources.Categories.query.parameters.currentUserOU = ou;
  
  ds.properties.Ou = ou;

  function go() {
    go__step += 1;
    if (go__step === go__max) {
      app.datasources.Audience.selectKey(ds.item._key);
    }
  }

  app.datasources.Audience.load(go);
  app.datasources.Categories.load(go);
  
  ds.load(function () {
    if (ds.items.length > 0) {
      if (!ds.item.Active) ds.item.Active = true;
      go();
    } else {
      throw Error("Could not find any ou by " + ou);
    }
  });
}

function onButtonLoad(datasource) {
  var changes = false;
  datasource.items.forEach(function (item, ix) {
    if (item.Position !== ix+1) {
      changes = true;
      item.Position = ix+1;
    }
  });

  if (changes) {
    app.popups.Snackbar.properties.informText = 'Cleaning up…';
    app.popups.Snackbar.visible = true;
    datasource.saveChanges(function () { 
      app.popups.Snackbar.properties.informText = 'Complete';
      setTimeout(function () {
        app.popups.Snackbar.visible = false;
      });
    });
  } 
}